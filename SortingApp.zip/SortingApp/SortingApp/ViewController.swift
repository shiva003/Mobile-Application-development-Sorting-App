//
//  ViewController.swift
//  SortingApp
//
//  Created by Shiva Medapati on 9/14/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textFieldInput: UITextField!
    @IBOutlet weak var labelOutput: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var SegmentControlSelection: UISegmentedControl!
    
    func sortIntegers(){
        //code for integers and Strings
        var inp = textFieldInput.text!
        labelOutput.text = inp
        var inpArr = inp.split(separator: ",");
        var integerArr = inpArr.map { Int($0)!}
        integerArr.sort( )
        let outString = integerArr.map{String($0)}
        let dispoutput = outString.joined(separator:", ")
        labelOutput.text = dispoutput;
        
    }
    func sortStrings(){
        //code for integers and Strings
        var inp = textFieldInput.text!
        labelOutput.text = inp
        var inpArr = inp.split(separator: ",");
        inpArr.sort( )
        let dispoutput = inpArr.joined(separator:", ")
        labelOutput.text = dispoutput;
        
    }
    // function for sorting Dates
    func sortforDates(){
        var inp = textFieldInput.text!;
                var inpArray = inp.split(separator: ",");
                var dateObj = [Date]()
                let dateFormat = DateFormatter()
                dateFormat.dateFormat = "mm/dd/yyyy"
                for date in inpArray{
                    let dateObject = dateFormat.date(from: String(date))
                        dateObj.append(dateObject!)
                    }
                dateObj.sort();
                var dispout = "";
                for dateObject in dateObj{
                    let dateStr = dateFormat.string(from: dateObject)
                        dispout.append(dateStr+", ")
                    }
                labelOutput.text = String(dispout.dropLast(2))
                
            }
    

    @IBAction func btnActionSort(_ sender: Any) {
        switch SegmentControlSelection.selectedSegmentIndex {
        case 0:
            sortIntegers()
        case 1:
            sortStrings()
        case 2:
            sortforDates()
        default:
            break;
        }
        
    }

    
    @IBAction func btnActionClear(_ sender: Any) {
        textFieldInput.text = " "
        labelOutput.text = "Output"
    }

}

